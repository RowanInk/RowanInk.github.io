KEVIN DE JONKE UNITED — WEBSITE DRAFT v2

Contents:
- index.html: responsive black-and-white website with the supplied origin story, timeline, indoor player list and FC 24 Pro Clubs list.
- This is a static website draft, not yet published online.

Preview:
1. Download the ZIP.
2. Extract it.
3. Open index.html in a web browser.

Publish:
Upload the files to a static hosting service such as GitHub Pages. The website will not be public until that step is completed.

Before publishing:
- Confirm all names, spellings, roles and dates.
- Consider replacing the jokey player description with wording the player is happy to have online.
- Get permission before publicly publishing identifiable information about youth players or using their photos.
- Add official competition links and reliable sources as they become available.

The page includes basic metadata and SportsOrganization structured data. These can help systems understand the site but do not guarantee search indexing or AI answers.
